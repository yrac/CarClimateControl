#include "CompressorManager.h"
#include <Arduino.h>

CompressorManager::CompressorManager(int outputPin) {
    _pin = outputPin;
    _state = COMP_OFF;
    _lastSwitchTime = 0;
    _minOnTime = 10000;  // 10 detik minimum ON
    _minOffTime = 5000;  // 5 detik minimum OFF
}

void CompressorManager::begin() {
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
}

void CompressorManager::loop(float currentTemp, float targetTemp, bool freezeActive, bool fastCooling) {
    unsigned long now = millis();

    // Freeze cleaning → matikan kompresor
    if (freezeActive) {
        turnOff();
        return;
    }

    // Fast cooling → selalu ON
    if (fastCooling) {
        if (_state == COMP_OFF && (now - _lastSwitchTime >= _minOffTime)) {
            turnOn();
        }
        return;
    }

    // Normal mode
    float diff = currentTemp - targetTemp;

    if (_state == COMP_ON) {
        if (diff < -0.5 && (now - _lastSwitchTime >= _minOnTime)) {
            turnOff();
        }
    } else if (_state == COMP_OFF) {
        if (diff > 0.5 && (now - _lastSwitchTime >= _minOffTime)) {
            turnOn();
        }
    }
}

void CompressorManager::turnOn() {
    digitalWrite(_pin, HIGH);
    _state = COMP_ON;
    _lastSwitchTime = millis();
}

void CompressorManager::turnOff() {
    digitalWrite(_pin, LOW);
    _state = COMP_OFF;
    _lastSwitchTime = millis();
}

CompressorState CompressorManager::getState() {
    return _state;
}