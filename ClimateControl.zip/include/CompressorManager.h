#ifndef COMPRESSORMANAGER_H
#define COMPRESSORMANAGER_H

#include "TempSensor.h"
#include "Potentiometer.h"

enum CompressorState {
    COMP_OFF,
    COMP_ON,
    COMP_HOLD
};

class CompressorManager {
public:
    CompressorManager(int outputPin);
    void begin();
    void loop(float currentTemp, float targetTemp, bool freezeActive, bool fastCooling);
    CompressorState getState();

private:
    int _pin;
    CompressorState _state;
    unsigned long _lastSwitchTime;
    unsigned long _minOnTime;
    unsigned long _minOffTime;

    void turnOn();
    void turnOff();
};

#endif